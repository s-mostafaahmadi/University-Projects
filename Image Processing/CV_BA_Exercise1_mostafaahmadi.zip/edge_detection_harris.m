clc;
clear all;

% خواندن تصویر و تبدیل به خاکستری
I = imread('Lenna.png');
I = rgb2gray(I);

% تبدیل به داده‌های دوبرابر (double)
I = double(I);

% پارامترها
window_size = 3;
k = 0.01; % پارامتر حساسیت

% محاسبه مشتقات
[Gx, Gy] = gradient(I);

% محاسبه محصولات گرادیان
Ix2 = Gx.^2;
Iy2 = Gy.^2;
Ixy = Gx .* Gy;

% فیلتر گاوسی برای هموارسازی
sigma = 1.5;
g = fspecial('gaussian', window_size, sigma);

% هموارسازی محصولات گرادیان
Sx2 = imfilter(Ix2, g);
Sy2 = imfilter(Iy2, g);
Sxy = imfilter(Ixy, g);

% محاسبه ماتریس پاسخ هریس
R = (Sx2 .* Sy2 - Sxy.^2) - k * (Sx2 + Sy2).^2;

% نرمال‌سازی پاسخ برای نمایش
R = R / max(max(R));

% آستانه‌گذاری
threshold = 0.01;
corner_peaks = (R > threshold) & (imdilate(R, strel('disk', 1)) == R);

% یافتن مختصات نقاط گوشه‌ای
[corner_y, corner_x] = find(corner_peaks);

% نمایش تصویر و نقاط گوشه‌ای
imshow(I, []);
hold on;
plot(corner_x, corner_y, 'r*');
hold off;
