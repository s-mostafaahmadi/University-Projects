function image_processing_gui
    % ایجاد شکل اصلی رابط کاربری
    hFig = figure('Name', 'Image Processing GUI', 'NumberTitle', 'off', 'MenuBar', 'none', 'ToolBar', 'none', 'Position', [100, 100, 800, 600]);

    % ایجاد دکمه‌ها و سایر کنترل‌ها
    uicontrol('Style', 'pushbutton', 'String', 'Open Image', 'Position', [20, 550, 100, 30], 'Callback', @openImage);
    uicontrol('Style', 'pushbutton', 'String', 'Grayscale', 'Position', [20, 500, 100, 30], 'Callback', @convertToGrayscale);
    uicontrol('Style', 'pushbutton', 'String', 'Blur', 'Position', [20, 450, 100, 30], 'Callback', @blurImage);
    uicontrol('Style', 'pushbutton', 'String', 'Sharpen', 'Position', [20, 400, 100, 30], 'Callback', @sharpenImage);
    uicontrol('Style', 'pushbutton', 'String', 'Increase Contrast', 'Position', [20, 350, 100, 30], 'Callback', @increaseContrast);
    uicontrol('Style', 'popupmenu', 'String', {'Sobel', 'Canny'}, 'Position', [20, 300, 100, 30], 'Callback', @edgeDetection);
    uicontrol('Style', 'popupmenu', 'String', {'Harris', 'SIFT'}, 'Position', [20, 250, 100, 30], 'Callback', @featureDetection);
    uicontrol('Style', 'pushbutton', 'String', 'Rotate 90°', 'Position', [20, 200, 100, 30], 'Callback', @rotateImage);
    uicontrol('Style', 'pushbutton', 'String', 'Flip', 'Position', [20, 150, 100, 30], 'Callback', @flipImage);
    uicontrol('Style', 'pushbutton', 'String', 'Reset', 'Position', [20, 100, 100, 30], 'Callback', @resetImage);
    uicontrol('Style', 'pushbutton', 'String', 'Save Image', 'Position', [20, 50, 100, 30], 'Callback', @saveImage);

    % ایجاد محلی برای نمایش تصویر
    hAxes = axes('Parent', hFig, 'Units', 'Pixels', 'Position', [150, 50, 600, 500]);

    % متغیرهای گلوبال برای ذخیره تصویر اولیه و پردازش‌شده
    global originalImage processedImage;
    global cornersDetected;
    global pointsDetected;
    originalImage = [];
    processedImage = [];
    cornersDetected = [];
    pointsDetected = [];

    function openImage(~, ~)
        [filename, pathname] = uigetfile({'*.jpg;*.png;*.bmp', 'Image Files'}, 'Select an Image');
        if isequal(filename, 0)
            return;
        end
        originalImage = imread(fullfile(pathname, filename));
        processedImage = originalImage;
        imshow(processedImage, 'Parent', hAxes);
    end

    function convertToGrayscale(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = rgb2gray(processedImage);
        imshow(processedImage, 'Parent', hAxes);
    end

    function blurImage(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = imgaussfilt(processedImage, 2);
        imshow(processedImage, 'Parent', hAxes);
    end

    function sharpenImage(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = imsharpen(processedImage);
        imshow(processedImage, 'Parent', hAxes);
    end

    function increaseContrast(~, ~)
        persistent contrastFactor; % مقدار پایدار فاکتور افزایش کنتراست
        
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        
        % اگر مقدار پایدار فاکتور افزایش کنتراست وجود نداشته باشد، آن را به یک مقدار اولیه تنظیم کنید
        if isempty(contrastFactor)
            contrastFactor = 1.1; % مقدار اولیه فاکتور افزایش کنتراست
        end
        
        % اعمال فاکتور افزایش کنتراست بر روی تصویر
        if size(processedImage, 3) == 3 % اگر تصویر RGB است
            % اعمال تابع imadjust بر روی هر کانال
            for i = 1:3
                processedImage(:, :, i) = imadjust(processedImage(:, :, i), [], [], contrastFactor);
            end
        else % اگر تصویر خاکستری است
            processedImage = imadjust(processedImage, [], [], contrastFactor); % اعمال تابع imadjust بر روی تصویر خاکستری
        end
        
        % نمایش تصویر پردازش شده
        imshow(processedImage, 'Parent', hAxes);
        
        % افزایش فاکتور کنتراست برای بار بعدی
        contrastFactor = contrastFactor + 0.1;
    end

    function edgeDetection(src, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        method = src.String{src.Value};
        resetImage();  % بازنشانی تصویر به حالت اصلی قبل از اعمال فیلتر
        if strcmp(method, 'Sobel')
            processedImage = edge(rgb2gray(processedImage), 'Sobel');
        elseif strcmp(method, 'Canny')
            processedImage = edge(rgb2gray(processedImage), 'Canny');
        end
        imshow(processedImage, 'Parent', hAxes);
    end

    function featureDetection(src, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        method = src.String{src.Value};
        resetImage();  % بازنشانی تصویر به حالت اصلی قبل از اعمال روش‌های Harris یا SIFT
        cornersDetected = [];  % پاکسازی گوشه‌های قبلی
        pointsDetected = [];
        if strcmp(method, 'Harris')
            corners = detectHarrisFeatures(rgb2gray(processedImage));
            cornersDetected = corners.selectStrongest(50).Location;
            processedImageWithFeatures = insertMarker(processedImage, cornersDetected, 'x', 'Color', 'green', 'Size', 10);
            imshow(processedImageWithFeatures, 'Parent', hAxes);
        elseif strcmp(method, 'SIFT')
            points = detectSURFFeatures(rgb2gray(processedImage));
            pointsDetected = points.selectStrongest(50).Location;
            processedImageWithFeatures = insertMarker(processedImage, pointsDetected, 'x', 'Color', 'green', 'Size', 10);
            imshow(processedImageWithFeatures, 'Parent', hAxes);  hold on;
            plot(points.selectStrongest(50));
        end
    end

    function rotateImage(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = imrotate(processedImage, 90);
        cla(hAxes);  % پاکسازی محور
        imshow(processedImage, 'Parent', hAxes);
    end

    function flipImage(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = flip(processedImage, 2); % Flip افقی
        imshow(processedImage, 'Parent', hAxes);
    end

    function resetImage(~, ~)
        if isempty(originalImage)
            errordlg('No image loaded');
            return;
        end
        processedImage = originalImage;
        imshow(processedImage, 'Parent', hAxes);
    end

    function saveImage(~, ~)
        if isempty(processedImage)
            errordlg('No image loaded');
            return;
        end
        [filename, pathname] = uiputfile({'*.jpg;*.png;*.bmp', 'Image Files'}, 'Save Image');
        if isequal(filename, 0)
            return;
        end

        % اضافه کردن گوشه‌های تشخیص‌داده‌شده در صورت وجود
        if ~isempty(cornersDetected)
            processedImageWithFeatures = insertMarker(processedImage, cornersDetected, 'x', 'Color', 'green', 'Size', 10);
            imwrite(processedImageWithFeatures, fullfile(pathname, filename));
        elseif ~isempty(pointsDetected)
            processedImageWithFeatures = insertMarker(processedImage, pointsDetected, 'x', 'Color', 'green', 'Size', 10);
            imwrite(processedImageWithFeatures, fullfile(pathname, filename));
        else
            imwrite(processedImage, fullfile(pathname, filename));
        end
    end
end
